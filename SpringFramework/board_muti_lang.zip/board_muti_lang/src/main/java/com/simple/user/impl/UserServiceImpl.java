package com.simple.user.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simple.user.UserVO;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDAO;
	
//	public void setUserDAO(UserDAO userDAO) {
//		this.userDAO = userDAO;
//	}
	
	@Override
	public UserVO getUser(UserVO vo) {			
		return userDAO.getUser(vo);
	}

	@Override
	public int insertUser(UserVO vo) {
		
		if(getUser(vo) == null) {
			userDAO.insertUser(vo);	
			return 0;
		}else {
			return -1;
		}		
	}

	@Override
	public void deletetUser(UserVO vo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateUser(UserVO vo) {
		// TODO Auto-generated method stub		
	}

	@Override
	public List<UserVO> getUserList(UserVO vo) {
		return userDAO.getUserList(vo);
	}

}
