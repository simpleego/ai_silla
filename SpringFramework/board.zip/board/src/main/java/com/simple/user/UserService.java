package com.simple.user;

public interface UserService {
	
	// 사용자 조회
	UserVO getUser(UserVO vo);

}
