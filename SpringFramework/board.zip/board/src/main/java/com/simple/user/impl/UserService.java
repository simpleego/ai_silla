package com.simple.user.impl;

import java.util.List;

import com.simple.user.UserVO;

public interface UserService {	
	// 사용자 추가
	int insertUser(UserVO vo);	
	// 사용자 삭제
	void deletetUser(UserVO vo);	
	// 사용자 수정
	void updateUser(UserVO vo);	
	// 사용자 조회	
	UserVO getUser(UserVO vo);	
	// 사용자 목록 조회
	List<UserVO> getUserList(UserVO vo);

}
