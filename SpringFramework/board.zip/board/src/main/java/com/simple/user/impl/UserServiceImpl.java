package com.simple.user.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simple.user.UserDAO;
import com.simple.user.UserService;
import com.simple.user.UserVO;

public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDAO;
	
	@Override
	public UserVO getUser(UserVO vo) {	
		
		return userDAO.getUser(vo);
	}

}
