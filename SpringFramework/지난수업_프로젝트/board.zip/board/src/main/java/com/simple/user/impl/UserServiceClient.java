package com.simple.user.impl;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.simple.board.BoardVO;
import com.simple.user.UserVO;

public class UserServiceClient {

	public static void main(String[] args) {

		// 1. Spring 컨테이너 구동한다.
		AbstractApplicationContext container = new GenericXmlApplicationContext("applicationContext.xml");

		// 2. Spring 컨테이너로부터 UserServiceImpl 객체를 Lookup 한다.
		UserService userService = (UserService) container.getBean("userService");

		// 3. 로그인 기능 테스트
//		UserVO vo = new UserVO();
//		vo.setId("test");
//		vo.setPassword("test123");

		// 3. 사용자 등록 기능 테스트
//		UserVO vo = new UserVO();
//		vo.setId("simple1");
//		vo.setName("박종천1");
//		vo.setPassword("pjc0129");
//		vo.setRole("user");

		// 4. 사용자 등록 기능 호출
//		UserVO user = new UserVO();
//		int userNum = 0;
//		// user = userService.getUser(vo);
//		userNum = userService.insertUser(vo);
//
//		if (userNum == -1) {
//			System.out.println("아이디가 존재합니다\n 새로운 아이디를 입력!!");
//		} else {
//			System.out.println("회원 등록이 정상적으로 되었습니다.");
//		}

		/*
		 * if (user != null) { // 로그인 성공 System.out.println("아이디:"+user.getId());
		 * System.out.println("이름:"+user.getName());
		 * System.out.println("역할:"+user.getRole()); }else { // 로그인 실패
		 * System.out.println("로그인 실패 :  아이디/비번 확인!!"); }
		 */
		
		UserVO vo = new UserVO();
		vo.setId("test");
		vo.setPassword("test123");
		
		UserVO user = userService.getUser(vo);

		// 4. 게시판 등록 글을 확인( 게시판 목록 기능 호출)
		List<UserVO> userList = userService.getUserList(vo);
		for (UserVO u : userList) {
			System.out.println("--->" + u);
		}

		// 5. container 종료
		container.close();

	}

}