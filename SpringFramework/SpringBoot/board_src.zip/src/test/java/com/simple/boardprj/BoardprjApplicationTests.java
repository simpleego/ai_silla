package com.simple.boardprj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardprjApplicationTests {

	@Test
	void contextLoads() {
	}

}
