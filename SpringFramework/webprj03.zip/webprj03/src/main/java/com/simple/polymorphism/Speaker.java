package com.simple.polymorphism;

public interface Speaker {
	void volumeUp();
	void volumeDown();
}
