package com.simple.view.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.simple.board.BoardVO;
import com.simple.board.impl.BoardDAO;
import com.simple.user.UserVO;
import com.simple.user.impl.UserDAO;

/**
 * Servlet implementation class DispatcherServlet
 */

public class DispatcherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private HandlerMapping handlermapping;
	private ViewResolve viewResolve;
	
	@Override
	public void init() throws ServletException {		
		handlermapping = new HandlerMapping();
		viewResolve = new ViewResolve();
		viewResolve.setPrefix("./");
		viewResolve.setSuffix(".jsp");			
	}
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 1. 클라이언트 요청을 분석
		String uri = request.getRequestURI();
		System.out.println("uri:" + uri);
		String path = uri.substring(uri.lastIndexOf("/"));
		System.out.println("path:" + path);
		
		// 2. HandlerMapping을 통해 path에 해당하는 Controller를 검색한다.
		Controller ctrl = handlermapping.getController(path); // 그럼 /login.do가 가서 mapping된 객체 가져온다.

		// 3. 검색된 Controller를 실행한다.
		String viewName = ctrl.handlerRequset(request, response);

		System.out.println("==>1."+viewName);
		// 4.
		String view = null;
		if (!viewName.contains(".do")) {
			view = viewResolve.getView(viewName);
			System.out.println("==>2."+view);
		} else {
			view = viewName;
		}

		// 5. 검색된 화면으로 이동한다.
		response.sendRedirect(view);
	}
		
}
