package com.simple.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.simple.board.BoardVO;
import com.simple.common.JDBCUtil;
import com.simple.user.UserVO;

@Repository("userDAO")
public class UserDAO {

	// JDBC 관련 변수
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	// SQL
	private final String USER_INSERT = "INSERT INTO users(id, name, password, role) " + "VALUES(?,?,?,?);";
	private String USER_GET = "SELECT * FROM USERS WHERE ID=? AND PASSWORD=?";
	private String USER_CREATE = "SELECT * FROM USERS WHERE ID=?";
	private String USER_LIST = "SELECT * FROM USERS";

	// CRUD 기능의 메소드 구현
	// 회원 등록
	public void insertUser(UserVO vo) {
		System.out.println("==>JDBC로 insertUser() 기능처리 ");
		// DB 접속
		// 문장객체 생성
		// SQL 전송(실행)

		conn = JDBCUtil.getConnection();
		try {
			pstmt = conn.prepareStatement(USER_INSERT);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getName());
			pstmt.setString(3, vo.getPassword());
			pstmt.setString(4, vo.getRole());
			// SQL 실행
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt, conn);
		}
	}

	// 회원 정보 얻기
	public UserVO getUser(UserVO vo) {
		UserVO user = null;
		try {
			System.out.println("===> JDBC로 getUser() 기능 처리");
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(USER_GET);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPassword());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				user = new UserVO();
				user.setId(rs.getString("ID"));
				user.setPassword(rs.getString("PASSWORD"));
				user.setName(rs.getString("NAME"));
				user.setRole(rs.getString("ROLE"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return user;
	}
	
	// 사용자 목록 조회
	public List<UserVO> getUserList(UserVO vo) {
		System.out.println("==>JDBC로 getUserList() 기능처리 ");
		
		List<UserVO> userList = new ArrayList<>();
		
		// DB 접속
		// 문장객체 생성
		// SQL 전송(실행)

		conn = JDBCUtil.getConnection();
		try {
			pstmt = conn.prepareStatement(USER_LIST);			
			// SQL 실행
			rs = pstmt.executeQuery();

			// SQL 실행 결과 처리
			while(rs.next()) {
				UserVO user = new UserVO();
				user.setId(rs.getString("ID"));
				user.setPassword(rs.getString("PASSWORD"));
				user.setName(rs.getString("NAME"));
				user.setRole(rs.getString("ROLE"));
				
				userList.add(user);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt, conn);
		}

		return userList;
	}

}
