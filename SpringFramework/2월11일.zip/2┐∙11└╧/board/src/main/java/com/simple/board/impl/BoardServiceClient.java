package com.simple.board.impl;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.simple.board.BoardVO;

public class BoardServiceClient {

	public static void main(String[] args) {

		// 1. Spring 컨테이너를 구동한다.
		AbstractApplicationContext container = new GenericXmlApplicationContext("applicationContext.xml");

		// 2. Spring 컨테이너로부터 BoardServiceImpl 객체를 Lookup 한다.
		BoardService boardService = (BoardService) container.getBean("boardService");
		
		// 3. 글 등록 기능 테스트
		// 게시판 입력 글 준비
		BoardVO vo = new BoardVO();
		vo.setTitle("임시 제목10");
		vo.setWriter("simple");
		vo.setContent("임시 내용10................");
		boardService.insertBoard(vo);
		
		// 글 수정
//		BoardVO vo = new BoardVO();
//		vo.setSeq(3);
//		vo.setTitle("수정 제목1");
//		vo.setContent("수정된 내용1................");
		
		// 글 삭제
//		BoardVO vo = new BoardVO();
//		vo.setSeq(3);
		
		//BoardVO vo = new BoardVO();
		//vo.setSeq(2);
		
		// 게시판 등록 기능 호출
		// boardService.insertBoard(vo);	
		// boardService.updateBoard(vo);
		//boardService.deleteBoard(vo);
		//BoardVO board1 = new BoardVO();
		//board1 =  boardService.getBoard(vo);
		
		//System.out.println(board1);
		
		// 4. 게시판 등록 글을 확인( 게시판 목록 기능 호출)
		List<BoardVO>  boardList = boardService.getBoardList(vo);
		for(BoardVO board : boardList) {
			System.out.println("--->"+board);			
		}
		
		// 5. container 종료
		container.close();
	}

}
